local shared = require 'SAMemory.shared'
shared.require 'CEntity'

-- The unified engine stores the transform directly in the entity prefix.  Do
-- not reuse the legacy CPlaceable layout (which contained a different matrix
-- ownership model).
shared.ffi.cdef[[
    typedef CEntity CPlaceable;
]]

return true
